﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB1
{
    public partial class AssessmentComponents : Form
    {
        string ID_UpDate = "";
        public AssessmentComponents()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            this.Hide();
            LOGIN form = new LOGIN();
            form.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (var con = Configuration.getInstance().getConnection())
                {
                    con.Open(); // Open the connection before executing the command

                    if (this.textBox1.Text != "" && this.comboBox2.SelectedIndex > -1 && this.comboBox1.SelectedIndex > -1 && this.textBox2.Text != "")
                    {
                        SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[AssessmentComponent] (Name, RubricId, TotalMarks, DateCreated, DateUpdated, AssessmentId) VALUES (@Name, @RubricId, @TotalMarks, @DateCreated, @DateUpdated, @AssessmentId)", con);
                        cmd.Parameters.AddWithValue("@Name", this.textBox1.Text);
                        cmd.Parameters.AddWithValue("@RubricId", comboBox1.Text);
                        cmd.Parameters.AddWithValue("@AssessmentId", comboBox2.Text);
                        cmd.Parameters.AddWithValue("@TotalMarks", this.textBox2.Text);
                        cmd.Parameters.AddWithValue("@DateCreated", dateTimePicker1.Value);
                        cmd.Parameters.AddWithValue("@DateUpdated", dateTimePicker2.Value);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Successfully saved");
                        this.textBox1.Text = "";
                        this.comboBox1.Text = "Rubric ID";
                        comboBox2.Text = "Assessment ID";
                        this.textBox2.Text = "";
                        load_data_in_data_gride_view();
                    }
                    else
                    {
                        MessageBox.Show("Please provide values for all fields.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }


        }
        public void load_data_in_data_gride_view()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from [dbo].[AssessmentComponent]  ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void data()
        {
            String ConnectionStr = @"Data Source=IFRA-FAZAL;Initial Catalog=ProjectB;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(ConnectionStr))
            {
                using (SqlCommand cmd = new SqlCommand("Select * from AssessmentComponent", con))
                {

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
        }
        private void AssessmentComponents_Load(object sender, EventArgs e)
        {
            Fill();
            Fill2();
            load_data_in_data_gride_view();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Please provide a name to be deleted.");
                }
                else
                {
                    using (var con = Configuration.getInstance().getConnection())
                    {
                        con.Open(); // Open the connection before executing the command

                        string deleteQuery = "DELETE FROM AssessmentComponent WHERE Name = @Name";
                        using (SqlCommand cmd = new SqlCommand(deleteQuery, con))
                        {
                            cmd.Parameters.AddWithValue("@Name", textBox1.Text);

                            // Execute SQL command
                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Record has been deleted successfully.");
                                // Refresh UI and update data
                                this.Refresh();
                                data();
                            }
                            else
                            {
                                MessageBox.Show("No record found with the provided name.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

            private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if Name field is provided
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Please provide a name to be edited.");
                }
                else
                {
                    // Get a database connection
                    using (var con = Configuration.getInstance().getConnection())
                    {
                        con.Open(); // Open the connection before executing the command

                        // Prepare SQL command for updating record
                        string updateQuery = "UPDATE AssessmentComponent SET TotalMarks=@TotalMarks, RubricId=@RubricId, AssessmentId=@AssessmentId, DateCreated=@DateCreated, DateUpdated=@DateUpdated WHERE Name= @Name";
                        using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                        {
                            // Set parameters for the SQL command
                            cmd.Parameters.AddWithValue("@Name", textBox1.Text);

                            // Parse and set RubricId, handle parse errors gracefully
                            if (int.TryParse(comboBox1.Text, out int rubricId))
                            {
                                cmd.Parameters.AddWithValue("@RubricId", rubricId);
                            }
                            else
                            {
                                MessageBox.Show("Invalid value for RubricId. Please select a valid integer from the dropdown.");
                                return;
                            }

                            // Parse and set TotalMarks, handle parse errors gracefully
                            if (int.TryParse(textBox2.Text, out int totalMarks))
                            {
                                cmd.Parameters.AddWithValue("@TotalMarks", totalMarks);
                            }
                            else
                            {
                                MessageBox.Show("Invalid value for TotalMarks. Please enter a valid integer.");
                                return;
                            }

                            // Parse and set AssessmentId, handle parse errors gracefully
                            if (int.TryParse(comboBox2.Text, out int assessmentId))
                            {
                                cmd.Parameters.AddWithValue("@AssessmentId", assessmentId);
                            }
                            else
                            {
                                MessageBox.Show("Invalid value for AssessmentId. Please select a valid integer from the dropdown.");
                                return;
                            }

                            // Set DateCreated and DateUpdated parameters
                            cmd.Parameters.AddWithValue("@DateCreated", dateTimePicker1.Value);
                            cmd.Parameters.AddWithValue("@DateUpdated", dateTimePicker2.Value);

                            // Execute SQL command
                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Record has been successfully edited.");

                                // Refresh UI and update data
                                this.Refresh();
                                data();
                            }
                            else
                            {
                                MessageBox.Show("No record found with the provided name.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }


        }

        private void button6_Click(object sender, EventArgs e)
        {

            String connection = @"Data Source=IFRA-FAZAL;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select * from AssessmentComponent";
            PDF(connection, query);
            MessageBox.Show("Pdf Successfully Created!!!");
        }
        public static void PDF(string connectionString, string query)
        {
            // Connect to the database and retrieve data
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Create a new PDF document and add a page
                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(@"C:\Users\ifraf\Desktop\4th Sem\DATABASE_LABS\DB1\AssessmentComponents.pdf", FileMode.Create));
                    //  PdfWriter.GetInstance(document, new FileStream("AssessmentComponent.pdf", FileMode.Create));
                    document.Open();

                    // Add a table to the PDF document
                    PdfPTable table = new PdfPTable(reader.FieldCount);
                    table.WidthPercentage = 100;
                    table.SetWidths(new float[] { 2f, 2f, 2f, 2f, 2f, 2f, 2f });

                    // Add headers to the table
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(reader.GetName(i)));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                        table.AddCell(cell);
                    }

                    // Add rows to the table
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            table.AddCell(reader[i].ToString());
                        }
                    }

                    // Add the table to the document
                    document.Add(table);

                    // Close the document and the reader
                    document.Close();
                    reader.Close();
                }
            }
        }

        private void comboBox2_MouseEnter(object sender, EventArgs e)
        {
            this.comboBox2.Items.Clear();
            this.comboBox2.ResetText();
            Fill2();

        }
        private void comboBox1_MouseEnter_1(object sender, EventArgs e)
        {

            this.comboBox1.Items.Clear();
            this.comboBox1.ResetText();
            Fill();
        }
        void Fill()
        {
            try
            {
                using (var con = Configuration.getInstance().getConnection())
                {
                    con.Open(); // Open the connection before executing the query

                    SqlCommand cmd = new SqlCommand("SELECT ID FROM Rubric", con);
                    SqlDataReader Sdr = cmd.ExecuteReader();

                    while (Sdr.Read())
                    {
                        comboBox1.Items.Add(Sdr["ID"].ToString());
                    }

                    Sdr.Close();
                    this.comboBox1.Text = "Rubric ID";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        void Fill2()
        {
            try
            {
                using (var con = Configuration.getInstance().getConnection())
                {
                    SqlCommand cmd = new SqlCommand("SELECT ID FROM Assessment", con);
                    con.Open(); // Open the connection before executing the query

                    using (SqlDataReader Sdr = cmd.ExecuteReader())
                    {
                        while (Sdr.Read())
                        {
                            comboBox2.Items.Add(Sdr["ID"].ToString());
                        }
                    }

                    comboBox2.Text = "Assesment ID";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

            try
            {
                // Check if any rows are selected
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Get the selected row
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    // Remove the selected row from the DataGridView
                    dataGridView1.Rows.Remove(selectedRow);

                    MessageBox.Show("Record removed from the grid successfully", "Success");
                }
                else
                {
                    MessageBox.Show("Please select a row to remove", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error");
            }
        
    }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
