﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB1
{
    public partial class RubricLevel : Form
    {

        string ID_UpDate = "";
        public RubricLevel()
        {
            InitializeComponent();
            load_data_in_data_gride_view();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            LOGIN form = new LOGIN();
            form.Show();
        }
        void Fillcombobox()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                con.Open(); // Open the connection

                SqlCommand cmd = new SqlCommand("select ID From Rubric", con);
                SqlDataReader Sdr = cmd.ExecuteReader();
                while (Sdr.Read())
                {
                    comboBox1.Items.Add(Sdr["ID"].ToString());
                }
                Sdr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }
        public void data()
        {
            var Con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from RubricLevel", Con);
            SqlDataAdapter dt = new SqlDataAdapter(cmd);
            DataTable dta = new DataTable();
            dt.Fill(dta);
            dataGridView1.DataSource = dta;

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
          
                if (this.textBox2.Text != "" && this.comboBox1.SelectedIndex > -1 && this.comboBox2.SelectedIndex > -1)
                {
                    if (!checked_already_present())
                    {
                        using (var con = Configuration.getInstance().getConnection())
                        {
                            con.Open(); // Open the connection
                            SqlCommand cmd = new SqlCommand("INSERT INTO RubricLevel (Details ,RubricId  , MeasurementLevel ) values(@Details, @RubricId , @MeasurementLevel )", con);
                            cmd.Parameters.AddWithValue("@Details", this.textBox2.Text);
                            cmd.Parameters.AddWithValue("@RubricId", comboBox1.Text);
                            cmd.Parameters.AddWithValue("@MeasurementLevel", this.comboBox2.SelectedIndex + 1);
                       // cmd.CommandTimeout = 120; // 2 minutes
                        cmd.ExecuteNonQuery();
                            MessageBox.Show("Successfully saved");
                            load_data_in_data_gride_view();
                            this.textBox2.Text = "";
                            this.comboBox1.Text = "Rubric ID";
                            this.comboBox2.Text = "Rubrics Level";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Already Present ");
                    }
                }
                else
                {
                    MessageBox.Show("Missing info ");
                }
            }

            private bool checked_already_present()
        {
            using (var con = Configuration.getInstance().getConnection())
            {
                con.Open(); // Open the connection

                SqlCommand cmd = new SqlCommand("select * from RubricLevel where RubricId = @RubricId and MeasurementLevel = @MeasurementLevel ", con);
                cmd.Parameters.AddWithValue("@RubricId", comboBox1.Text); // Changed comboBox1.Text to comboBox_Rubrics_ID.Text
                cmd.Parameters.AddWithValue("@MeasurementLevel", this.comboBox2.Text);
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Close();
                    return true;
                }

                dr.Close();
                return false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Please provide an ID to be deleted.");
                    return;
                }

               
                using (var con = Configuration.getInstance().getConnection())
                {
                    
                    using (SqlCommand cmd = con.CreateCommand())
                    {
                        cmd.CommandText = "DELETE FROM RubricLevel WHERE Id=@id";

                        cmd.Parameters.AddWithValue("@id", textBox1.Text);

                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record deleted successfully.");
                            data(); 
                        }
                        else
                        {
                            MessageBox.Show("No record found with the provided ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(this.ID_UpDate) && !string.IsNullOrWhiteSpace(this.textBox2.Text))
            {
                using (var con = Configuration.getInstance().getConnection())
                {
                    con.Open(); // Open the connection
                    SqlCommand cmd = new SqlCommand("UPDATE RubricLevel SET Details = @Details WHERE ID = @ID", con);
                    cmd.Parameters.AddWithValue("@ID", this.ID_UpDate.Trim());
                    cmd.Parameters.AddWithValue("@Details", this.textBox2.Text.Trim());
                    // Increase command timeout
                    cmd.CommandTimeout = 120; // 2 minutes

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully updated");
                    load_data_in_data_gride_view();
                    this.textBox2.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Missing info");
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            
                String connection = @"Data Source=IFRA-FAZAL;Initial Catalog=ProjectB;Integrated Security=True";
                string query = "Select * from RubricLevel";
                PDF(connection, query);
                MessageBox.Show("Pdf Successfully Created!!!");
            }
        public static void PDF(string connectionString, string query)
        {
            try
            {
                // Connect to the database and retrieve data
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        // Create a new PDF document and add a page
                        using (Document document = new Document())
                        {
                            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(@"C:\Users\ifraf\Desktop\4th Sem\DATABASE_LABS\DB1\RubricsLevel.pdf", FileMode.Create));

                            //   PdfWriter.GetInstance(document, new FileStream("Rubric.pdf", FileMode.Create));
                            document.Open();

                            // Add a table to the PDF document
                            PdfPTable table = new PdfPTable(reader.FieldCount);
                            table.WidthPercentage = 100;

                            // Add headers to the table
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(reader.GetName(i)));
                                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                                cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                                table.AddCell(cell);
                            }

                            // Add rows to the table
                            while (reader.Read())
                            {
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    table.AddCell(reader[i].ToString());
                                }
                            }

                            // Add the table to the document
                            document.Add(table);
                        }

                        // Close the reader
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }

        private void RubricLevel_Load(object sender, EventArgs e)
        {
            comboBox2.Items.Add("1"); // Assuming "1" represents the first measurement level
            comboBox2.Items.Add("2"); // Add more measurement levels as needed
            comboBox2.Items.Add("3");
            // Add more levels as needed

            // Select the first item by default
            comboBox2.SelectedIndex = 0;

            Fillcombobox();
        }

        public void load_data_in_data_gride_view()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from [dbo].[RubricLevel]  ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button8_Click(object sender, EventArgs e)
        {


            try
            {
                // Check if any rows are selected
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Get the selected row
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    // Remove the selected row from the DataGridView
                    dataGridView1.Rows.Remove(selectedRow);

                    MessageBox.Show("Record removed from the grid successfully", "Success");
                }
                else
                {
                    MessageBox.Show("Please select a row to remove", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error");
            }
        }
    }
    }
