﻿//using System;
//using System.Collections.Generic;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace DB1
//{
//    class Configuration
//    {
//        String ConnectionStr = @"Data Source=IFRA-FAZAL;Initial Catalog=ProjectB;Integrated Security=True";
//        SqlConnection con;
//        private static Configuration _instance;
//        public static Configuration getInstance()
//        {
//            if (_instance == null)
//                _instance = new Configuration();
//            return _instance;
//        }
//        private Configuration()
//        {
//            con = new SqlConnection(ConnectionStr);
//            con.Open();
//        }
//        public SqlConnection getConnection()
//        {
//            return con;
//        }
//    }
//}


using System;
using System.Data.SqlClient;

namespace DB1
{
    class Configuration
    {
        private static Configuration _instance;
        private string ConnectionStr;

        private Configuration()
        {
            // Initialize the connection string from configuration or other source
            ConnectionStr = @"Data Source=IFRA-FAZAL;Initial Catalog=ProjectB;Integrated Security=True";
        }

        public static Configuration getInstance()
        {
            if (_instance == null)
                _instance = new Configuration();
            return _instance;
        }

        public SqlConnection getConnection()
        {
            SqlConnection con = new SqlConnection(ConnectionStr);
            // Do not open the connection here, open it only when needed
            return con;
        }
    }
}
