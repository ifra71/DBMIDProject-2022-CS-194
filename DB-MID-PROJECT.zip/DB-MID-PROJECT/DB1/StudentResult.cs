﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB1
{
    public partial class StudentResult : Form
    {
        public StudentResult()
        {
            InitializeComponent();
            this.Refresh();
            data();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            LOGIN form = new LOGIN();
            form.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        using (var connection = Configuration.getInstance().getConnection())
        //        {
        //            string query = "INSERT INTO StudentResult (StudentId, AssessmentComponentId, RubricMeasurementId, EvaluationDate) " +
        //                           "VALUES (@StudentId, @AssessmentComponentId, @RubricMeasurementId, @EvaluationDate)";

        //            using (SqlCommand command = new SqlCommand(query, connection))
        //            {
        //                command.Parameters.AddWithValue("@StudentId", comboBox1.SelectedValue.ToString());
        //                command.Parameters.AddWithValue("@AssessmentComponentId", comboBox2.SelectedValue);
        //                command.Parameters.AddWithValue("@RubricMeasurementId", comboBox3.SelectedValue);
        //                command.Parameters.AddWithValue("@EvaluationDate", dateTimePicker1.Value);

        //                connection.Open();
        //                int rowsAffected = command.ExecuteNonQuery();

        //                if (rowsAffected > 0)
        //                {
        //                    MessageBox.Show("Successfully saved");
        //                    this.Refresh();
        //                    data();
        //                }
        //                else
        //                {
        //                    MessageBox.Show("Failed to save data");
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error occurred: " + ex.Message);
        //    }

        //}
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (var connection = Configuration.getInstance().getConnection())
                {
                    string selectedStudentId = comboBox3.SelectedItem?.ToString();

                    if (!string.IsNullOrEmpty(selectedStudentId))
                    {
                        string query = "INSERT INTO StudentResult (StudentId, AssessmentComponentId, RubricMeasurementId, EvaluationDate) " +
                                       "VALUES (@StudentId, @AssessmentComponentId, @RubricMeasurementId, @EvaluationDate)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@StudentId", selectedStudentId);
                            command.Parameters.AddWithValue("@AssessmentComponentId", comboBox2.SelectedValue);
                            command.Parameters.AddWithValue("@RubricMeasurementId", comboBox1.SelectedValue);
                            command.Parameters.AddWithValue("@EvaluationDate", dateTimePicker1.Value);

                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Successfully saved");
                                this.Refresh();
                                data();
                            }
                            else
                            {
                                MessageBox.Show("Failed to save data");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a student.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }


    

        public void data()
        {
            var Con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from StudentResult", Con);
            cmd.CommandTimeout = 120; // Increase the command timeout to 120 seconds (adjust as needed)
            SqlDataAdapter dt = new SqlDataAdapter(cmd);
            DataTable dta = new DataTable();
            dt.Fill(dta);
            dataGridView1.DataSource = dta;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = GetDataFromDatabase();

                // Create a new PDF document
                using (Document doc = new Document())
                {
                    PdfWriter.GetInstance(doc, new FileStream("StudentResultReport.pdf", FileMode.Create));
                    doc.Open();

                    // Add a table with headers
                    PdfPTable table = new PdfPTable(5);
                    AddTableHeaders(table);

                    // Add data rows to the table
                    foreach (DataRow row in dt.Rows)
                    {
                        int studentID = Convert.ToInt32(row["StudentID"]);
                        int component = Convert.ToInt32(row["AssessmentComponentId"]);
                        int rubricLevel = Convert.ToInt32(row["RubricMeasurementId"]);
                        DateTime evalDate = Convert.ToDateTime(row["EvaluationDate"]);
                        double maxRubricLevel = GetMaxRubricLevel(component);
                        double obtainedMarks = CalculateObtainedMarks(rubricLevel, maxRubricLevel, component);
                        AddRowToTable(table, studentID, component, rubricLevel, evalDate, obtainedMarks);
                    }

                    // Add the table to the document
                    doc.Add(table);
                }

                MessageBox.Show("PDF report generated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error occurred: {ex.Message}");
            }
        }

        private DataTable GetDataFromDatabase()
        {
            using (var con = Configuration.getInstance().getConnection())
            {
                string query = "SELECT StudentID, AssessmentComponentId, RubricMeasurementId, EvaluationDate FROM StudentResult";

                using (SqlCommand command = new SqlCommand(query, con))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        private void AddTableHeaders(PdfPTable table)
        {
            table.AddCell("Student ID");
            table.AddCell("Assessment Component");
            table.AddCell("Rubric Level");
            table.AddCell("Evaluation Date");
            table.AddCell("Obtained Marks");
        }

        private double CalculateObtainedMarks(int rubricLevel, double maxRubricLevel, int component)
        {
            double obtainedMarks = (rubricLevel / maxRubricLevel) * GetComponentMarks(component);
            return obtainedMarks;
        }

        private void AddRowToTable(PdfPTable table, int studentID, int component, int rubricLevel, DateTime evalDate, double obtainedMarks)
        {
            table.AddCell(studentID.ToString());
            table.AddCell(component.ToString());
            table.AddCell(rubricLevel.ToString());
            table.AddCell(evalDate.ToString());
            table.AddCell(obtainedMarks.ToString());
        }
        // Get the maximum rubric level for a given component
        private double GetMaxRubricLevel(int componentId)
        {
            using (var connection = Configuration.getInstance().getConnection())
            {
                string query = "SELECT MAX(RML.MeasurementLevel) " +
                               "FROM StudentResult SR " +
                               "JOIN RubricLevel RML ON SR.RubricMeasurementId = RML.Id";

                SqlCommand command = new SqlCommand(query, connection);
                object result = command.ExecuteScalar();

                if (result != null && double.TryParse(result.ToString(), out double maxLevel))
                {
                    return maxLevel;
                }
                else
                {
                    throw new ArgumentException("No data found for the component.");
                }
            }
        }

        
        private double GetComponentMarks(int componentId)
        {
            using (var connection = Configuration.getInstance().getConnection())
            {
                string query = $"SELECT TotalMarks FROM AssessmentComponent WHERE Id = {componentId}";

                SqlCommand command = new SqlCommand(query, connection);
                object result = command.ExecuteScalar();

                if (result != null && double.TryParse(result.ToString(), out double marks))
                {
                    return marks;
                }
                else
                {
                    throw new ArgumentException($"Invalid component: {componentId}");
                }
            }
        }

        private double GetObtainedMarks(int studentId, int componentId)
        {
            double maxLevel = GetMaxRubricLevel(componentId);
            double componentMarks = GetComponentMarks(componentId);

            using (var connection = Configuration.getInstance().getConnection())
            {
                string query = $"SELECT RubricMeasurementId FROM StudentResult WHERE StudentID = {studentId} AND AssessmentComponentId = {componentId}";

                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                double obtainedLevel = 0;
                while (reader.Read())
                {
                    int rubricLevelId = reader.GetInt32(0);
                    double measurementLevel = GetMeasurementLevel(rubricLevelId);
                    obtainedLevel += measurementLevel;
                }
                reader.Close();

                double obtainedMarks = (obtainedLevel / maxLevel) * componentMarks;
                return obtainedMarks;
            }
        }

      
        private double GetMeasurementLevel(int rubricLevelId)
        {
            using (var connection = Configuration.getInstance().getConnection())
            {
                string query = $"SELECT MeasurementLevel FROM RubricLevel WHERE Id = {rubricLevelId}";

                SqlCommand command = new SqlCommand(query, connection);
                object result = command.ExecuteScalar();

                if (result != null && double.TryParse(result.ToString(), out double measurementLevel))
                {
                    return measurementLevel;
                }
                else
                {
                    throw new ArgumentException($"Invalid rubric level: {rubricLevelId}");
                }
            }
        }


        private void button6_Click(object sender, EventArgs e)
        {
            String connection = @"Data Source=IFRA-FAZAL;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select * from StudentResult";
            PDF(connection, query);
            MessageBox.Show("Pdf Successfully Created!!!");
        }
        public static void PDF(string connectionString, string query)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(@"C:\Users\ifraf\Desktop\4th Sem\DATABASE_LABS\DB1\StudentResult.pdf", FileMode.Create));

                    document.Open();

                    PdfPTable table = new PdfPTable(reader.FieldCount);
                    table.WidthPercentage = 100;
                    table.SetWidths(new float[] { 2f, 2f, 2f, 2f });

                   
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(reader.GetName(i)));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                        table.AddCell(cell);
                    }

                 
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            table.AddCell(reader[i].ToString());
                        }
                    }

                    
                    document.Add(table);

                    document.Close();
                    reader.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("No ID provided for editing.");
            }
            else
            {
                try
                {
                    using (var connection = Configuration.getInstance().getConnection())
                    {
                        SqlCommand cmd = new SqlCommand("UPDATE StudentResult SET RubricMeasurementId = @RubricMeasurementId, AssessmentComponentId = @AssessmentComponentId, EvaluationDate = @EvaluationDate WHERE StudentId = @StudentId", connection);

                        cmd.Parameters.AddWithValue("@StudentId", comboBox1.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@AssessmentComponentId", comboBox2.SelectedValue);
                        cmd.Parameters.AddWithValue("@RubricMeasurementId", comboBox3.SelectedValue);
                        cmd.Parameters.AddWithValue("@EvaluationDate", dateTimePicker1.Value);

                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record has been successfully edited.");
                            this.Refresh();
                            data();
                        }
                        else
                        {
                            MessageBox.Show("No record found for the provided ID.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}");
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("No Student ID provided to be deleted.");
                }
                else
                {
                    using (var connection = Configuration.getInstance().getConnection())
                    {
                        SqlCommand cmd = new SqlCommand("DELETE FROM StudentResult WHERE StudentId = @StudentId", connection);
                        cmd.Parameters.AddWithValue("@StudentId", textBox1.Text);

                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record deleted successfully.");
                            this.Refresh();
                            data(); 
                        }
                        else
                        {
                            MessageBox.Show("No records found for the provided Student ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void StudentResult_Load(object sender, EventArgs e)
        {
            data();
           // LoadAssessmentTitles();
            LoadStudentRegistrationNumbers();
           // LoadRubricMeasurementLevels();
            LoadRubricMeasurementIds();
            LoadAssessmentComponentIds();
        }

      

        void LoadRubricMeasurementIds()
        {
            try
            {
                using (SqlConnection connection = Configuration.getInstance().getConnection())
                {
                    connection.Open(); // Open the connection before executing the command

                    SqlCommand command = new SqlCommand("SELECT Id FROM RubricLevel", connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox3.Items.Add(reader["Id"].ToString());
                    }

                    reader.Close();
                    comboBox3.Text = "Select Rubric Measurement ID";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        //void LoadStudentRegistrationNumbers()
        //{
        //    using (SqlConnection connection = Configuration.getInstance().getConnection())
        //    {
        //        connection.Open(); // Open the connection before executing the command

        //        SqlCommand command = new SqlCommand("SELECT RegistrationNumber FROM Student", connection);
        //        SqlDataReader reader = command.ExecuteReader();

        //        while (reader.Read())
        //        {
        //            comboBox1.Items.Add(reader["RegistrationNumber"].ToString());
        //        }

        //        reader.Close();
        //        comboBox1.Text = "Select Registration Number";
        //    }
        //}
        void LoadStudentRegistrationNumbers()
        {
            try
            {
                using (SqlConnection connection = Configuration.getInstance().getConnection())
                {
                    connection.Open(); // Open the connection before executing the command

                    SqlCommand command = new SqlCommand("SELECT Id FROM Student", connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox1.Items.Add(reader["Id"].ToString());
                    }

                    reader.Close();
                    comboBox1.Text = "Select Student ID";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        //void LoadRubricMeasurementLevels()
        //{
        //    using (SqlConnection connection = Configuration.getInstance().getConnection())
        //    {
        //        connection.Open(); // Open the connection before executing the command

        //        SqlCommand command = new SqlCommand("SELECT MeasurementLevel FROM RubricLevel", connection);
        //        SqlDataReader reader = command.ExecuteReader();

        //        while (reader.Read())
        //        {
        //            comboBox4.Items.Add(reader["MeasurementLevel"].ToString());
        //        }

        //        reader.Close();
        //        comboBox4.Text = "Select Level";
        //    }
        //}



        //void LoadAssessmentComponentIds()
        //{
        //    try
        //    {
        //        using (SqlConnection connection = Configuration.getInstance().getConnection())
        //        {
        //            connection.Open(); // Open the connection before executing the command

        //            SqlCommand command = new SqlCommand("SELECT Id FROM AssessmentComponent", connection);
        //            SqlDataReader reader = command.ExecuteReader();

        //            while (reader.Read())
        //            {
        //                comboBox2.Items.Add(reader["Id"].ToString());
        //            }

        //            reader.Close();
        //            comboBox2.Text = "Select Assessment Component ID";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show($"An error occurred: {ex.Message}");
        //    }
        //}
        void LoadAssessmentComponentIds()
        {
            try
            {
                using (SqlConnection connection = Configuration.getInstance().getConnection())
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand("SELECT Id FROM AssessmentComponent", connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox2.Items.Add(reader["Id"].ToString());
                    }

                    reader.Close();
                    comboBox2.Text = "Select Assessment Component ID";

                    // Set the ValueMember property to the appropriate column name
                    comboBox2.ValueMember = "Id";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
        private bool IsValidRegistrationNumber(string registrationNumber)
        {
            return registrationNumber.Length >= 9 && !string.IsNullOrWhiteSpace(registrationNumber);
        }
        private void button8_Click(object sender, EventArgs e)
        {

            try
            {
                if (dataGridView1.SelectedRows.Count > 0) // Check if any rows are selected
                {
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                    string registrationNumber = selectedRow.Cells["RegistrationNumber"].Value.ToString();

                    if (IsValidRegistrationNumber(registrationNumber))
                    {
                        // Remove the selected row from the DataGridView
                        dataGridView1.Rows.Remove(selectedRow);

                        MessageBox.Show("Record removed from the grid successfully", "Success");
                    }
                    else
                    {
                        MessageBox.Show("Invalid registration number", "Error");
                    }
                }
                else
                {
                    MessageBox.Show("Please select a row to delete", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

