﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace DB1
{
    public partial class StudentAttendence : Form
    {

        List<int> Stdent_id = new List<int>();
        bool check_event = true;
        int Count = 0;
        public StudentAttendence()
        {
            InitializeComponent();
            this.Stdent_id.Add(0);
            data();
        }

        public void data()
        {
            var Con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from StudentAttendance", Con);
            cmd.CommandTimeout = 120; // Increase the command timeout to 120 seconds (adjust as needed)
            SqlDataAdapter dt = new SqlDataAdapter(cmd);
            DataTable dta = new DataTable();
            dt.Fill(dta);
            dataGridView1.DataSource = dta;
        }
        public void load_data()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select concat([FirstName] ,' '  ,[LastName]) As Name , RegistrationNumber from Student  ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

    
        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (dataGridView1.CurrentCell.OwningColumn.Name == "Status")
            {
                if (e.Control is System.Windows.Forms.ComboBox combo)
                {
                    combo.SelectedIndexChanged -= Combo_SelectedIndexChanged;
                    combo.SelectedIndexChanged += Combo_SelectedIndexChanged;
                }
            }
        }
        private void Combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (check_event)
                {
                    System.Windows.Forms.ComboBox comboBox = sender as System.Windows.Forms.ComboBox;
                    if (comboBox != null)
                    {
                        int selectedIndex = comboBox.SelectedIndex + 1;
                        string selectedComboBoxItem = comboBox.SelectedItem.ToString();

                        int rowIndex = dataGridView1.CurrentCell.RowIndex;
                        int columnIndex = dataGridView1.CurrentCell.ColumnIndex;
                        string registrationNumber = dataGridView1.Rows[rowIndex].Cells["RegistrationNumber"].Value.ToString();

                        using (var con = Configuration.getInstance().getConnection())
                        {
                            if (Count == 0)
                            {
                                InsertAttendance(con);
                                Count++;
                            }

                            int attendanceId = GetAttendanceId(con);
                            int studentId = GetStudentId(con, registrationNumber);

                            InsertStudentAttendance(con, attendanceId, studentId, selectedIndex);
                            UpdateStudentStatus(con, studentId, selectedIndex);

                            // Refresh the DataGridView
                            load_data2();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void InsertAttendance(SqlConnection con)
        {
            SqlCommand cmdInsertAttendance = new SqlCommand("INSERT INTO ClassAttendance VALUES (@AttendanceDate)", con);
            cmdInsertAttendance.Parameters.AddWithValue("@AttendanceDate", dateTimePicker1.Value.ToString("dd/MM/yyyy"));
            cmdInsertAttendance.ExecuteNonQuery();
        }

        private int GetAttendanceId(SqlConnection con)
        {
            SqlCommand cmdSelectAttendanceId = new SqlCommand("SELECT Id FROM ClassAttendance WHERE AttendanceDate = @AttendanceDate", con);
            cmdSelectAttendanceId.Parameters.AddWithValue("@AttendanceDate", dateTimePicker1.Value.ToString("dd/MM/yyyy"));
            SqlDataReader readerAttendanceId = cmdSelectAttendanceId.ExecuteReader();

            int attendanceId = 0;
            if (readerAttendanceId.HasRows)
            {
                readerAttendanceId.Read();
                attendanceId = Convert.ToInt32(readerAttendanceId["Id"]);
            }
            readerAttendanceId.Close();

            return attendanceId;
        }

        private int GetStudentId(SqlConnection con, string registrationNumber)
        {
            SqlCommand cmdSelectStudentId = new SqlCommand("SELECT Id FROM Student WHERE RegistrationNumber = @RegistrationNumber", con);
            cmdSelectStudentId.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
            SqlDataReader readerStudentId = cmdSelectStudentId.ExecuteReader();

            int studentId = 0;
            if (readerStudentId.HasRows)
            {
                readerStudentId.Read();
                studentId = Convert.ToInt32(readerStudentId["Id"]);
            }
            readerStudentId.Close();

            return studentId;
        }

        private void InsertStudentAttendance(SqlConnection con, int attendanceId, int studentId, int selectedIndex)
        {
            SqlCommand cmdInsertStudentAttendance = new SqlCommand("INSERT INTO StudentAttendance VALUES (@AttendanceId, @StudentId, @AttendanceStatus)", con);
            cmdInsertStudentAttendance.Parameters.AddWithValue("@AttendanceId", attendanceId);
            cmdInsertStudentAttendance.Parameters.AddWithValue("@StudentId", studentId);
            cmdInsertStudentAttendance.Parameters.AddWithValue("@AttendanceStatus", selectedIndex);
            cmdInsertStudentAttendance.ExecuteNonQuery();
        }

        private void UpdateStudentStatus(SqlConnection con, int studentId, int selectedIndex)
        {
            SqlCommand cmdUpdateStatus = new SqlCommand("UPDATE Student SET Status = @Status WHERE ID = @ID", con);
            cmdUpdateStatus.Parameters.AddWithValue("@ID", studentId);
            cmdUpdateStatus.Parameters.AddWithValue("@Status", selectedIndex);
            cmdUpdateStatus.ExecuteNonQuery();
        }

        public void load_data2()
        {
            try
            {
                using (var con = Configuration.getInstance().getConnection())
                {
                    string studentIdsString = string.Join(",", Stdent_id);
                    string query = $"SELECT CONCAT([FirstName], ' ', [LastName]) AS Name, RegistrationNumber FROM Student WHERE id NOT IN ({studentIdsString})";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            dataGridView1.DataSource = dt;

                            if (dataGridView1.RowCount == 1)
                            {
                                MessageBox.Show("Today's attendance has already been marked.");
                                check_event = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public bool CheckPresentDate()
        {
            try
            {
                using (var con = Configuration.getInstance().getConnection())
                {
                    DateTime selectedDate = this.dateTimePicker1.Value;
                    SqlCommand cmd = new SqlCommand("SELECT AttendanceDate FROM ClassAttendance WHERE CAST(AttendanceDate AS DATE) = @AttendanceDate", con);
                    cmd.Parameters.AddWithValue("@AttendanceDate", selectedDate.Date);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read(); // Move to the first row of the result set
                        DateTime existingDate = Convert.ToDateTime(reader["AttendanceDate"]);
                        MessageBox.Show(existingDate.ToString("yyyy/MM/dd"));
                        MessageBox.Show("Record already exists.");
                        reader.Close();
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Record does not exist.");
                        reader.Close();
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }
        public bool IsDatePresentInTable()
        {
            try
            {
                DateTime selectedDate = this.dateTimePicker1.Value.Date; // Consider only the date part

                using (var con = Configuration.getInstance().getConnection())
                {
                    SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM ClassAttendance WHERE AttendanceDate = @AttendanceDate", con);
                    cmd.Parameters.AddWithValue("@AttendanceDate", selectedDate);

                    int rowCount = (int)cmd.ExecuteScalar(); // Use ExecuteScalar to get the count directly

                    return rowCount > 0; // Return true if the count is greater than 0, indicating presence of the date
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }
        private void LoadMarkedStudentsInDataGridView()
        {
            try
            {
                DateTime selectedDate = dateTimePicker1.Value.Date;

                using (var con = Configuration.getInstance().getConnection())
                {
                    string query = @"
                SELECT 
                    Lookup.Name AS Status, 
                    result.FirstName AS Name, 
                    result.RegistrationNumber AS RollNumber 
                FROM Lookup 
                JOIN (
                    SELECT 
                        SA.AttendanceStatus, 
                        S.FirstName, 
                        S.RegistrationNumber 
                    FROM 
                        Student AS S
                        JOIN StudentAttendance AS SA ON S.Id = SA.StudentId
                        JOIN ClassAttendance AS CA ON CA.Id = SA.AttendanceId 
                    WHERE 
                        CONVERT(date, CA.AttendanceDate) = @AttendanceDate
                ) AS result 
                ON Lookup.LookupId = result.AttendanceStatus";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@AttendanceDate", selectedDate);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Search")
            {
                textBox1.Text = "";
            }
        }

        private void txt_SearchName_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                textBox1.Text = "Search";
            }
        }

        private void txt_SearchName_TextChanged(object sender, EventArgs e)
        {
            string searchQuery = textBox1.Text.Trim();
            if (searchQuery == "Search")
            {
                return;
            }

            try
            {
                string columnName = comboBox1.SelectedIndex == 0 ? "RegistrationNumber" : "FirstName";
                string query = $"SELECT CONCAT([FirstName], ' ', [LastName]) AS Name, RegistrationNumber FROM Student WHERE {columnName} LIKE @SearchQuery";

                using (var con = Configuration.getInstance().getConnection())
                {
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@SearchQuery", searchQuery + "%");

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (searchQuery == "Search")
                {
                    load_data2();
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DateTime selectedDate = dateTimePicker1.Value.Date;

            if (!IsDatePresentInTable())
            {
                MessageBox.Show(selectedDate.ToString("dd/MM/yyyy"));
                load_data();
                check_event = true;
                dataGridView1.Columns["Status"].DisplayIndex = 3;
            }
            else
            {
                LoadMarkedStudentsInDataGridView();
                check_event = false;
                MessageBox.Show("Attendance for this day is already marked.");

                // Remove "UpdatesStatus" column if present and enable button2
                if (dataGridView1.Columns.Contains("UpdatesStatus"))
                {
                    dataGridView1.Columns.Remove("UpdatesStatus");
                    button2.Enabled = true;
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (this.check_event == false)
            {
               AddComboBoxColumn();
                this.button2.Enabled = false;
            }
        }
        private void AddComboBoxColumn()
        {
            // Create a new DataGridViewComboBoxColumn
            DataGridViewComboBoxColumn newColumn = new DataGridViewComboBoxColumn();

            // Set properties for the new column
            newColumn.HeaderText = "Updates Status";
            newColumn.Name = "UpdatesStatus";
            newColumn.FlatStyle = FlatStyle.Flat;
            newColumn.DisplayStyleForCurrentCellOnly = true;
            newColumn.ReadOnly = false;

            // Define items for the combo box
            List<string> comboBoxItems = new List<string>() { "Present", "Absent", "Leave", "Late" };
            newColumn.DataSource = comboBoxItems;

            // Add the column to the DataGridView
            dataGridView1.Columns.Add(newColumn);

            // Attach event handler for editing control showing
            dataGridView1.EditingControlShowing += DataGridView1_EditingControlShowing1;
        }
        private void DataGridView1_EditingControlShowing1(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (dataGridView1.CurrentCell.OwningColumn.Name == "UpdatesStatus")
            {
                System.Windows.Forms.ComboBox comboBox = e.Control as System.Windows.Forms.ComboBox;
                if (comboBox != null)
                {
                    comboBox.SelectedIndexChanged -= new EventHandler(ComboBox_SelectedIndexChanged);
                    comboBox.SelectedIndexChanged += ComboBox_SelectedIndexChanged;
                }
            }
        }
        private bool messageBoxShown = false;
        private void ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                System.Windows.Forms.ComboBox comboBox = sender as System.Windows.Forms.ComboBox;
                if (comboBox.SelectedItem != null && !messageBoxShown)
                {
                    DateTime selectedDate = dateTimePicker1.Value;
                    int day = selectedDate.Day;
                    int month = selectedDate.Month;
                    int year = selectedDate.Year;

                    messageBoxShown = true;
                    string selectedValue = comboBox.SelectedItem.ToString();
                    int rowIndex = dataGridView1.CurrentCell.RowIndex;
                    string registrationNumber = dataGridView1.Rows[rowIndex].Cells["RollNumber"].Value.ToString();

                    string query = @"
                UPDATE SA
                SET SA.AttendanceStatus = @AttendanceStatus
                FROM StudentAttendance AS SA
                JOIN ClassAttendance AS CA ON CA.Id = SA.AttendanceId
                JOIN Student AS S ON S.Id = SA.StudentId
                WHERE S.RegistrationNumber = @RegistrationNumber
                AND DAY(CA.AttendanceDate) = @day
                AND MONTH(CA.AttendanceDate) = @month
                AND YEAR(CA.AttendanceDate) = @year";

                    using (var con = Configuration.getInstance().getConnection())
                    {
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("@day", day);
                        cmd.Parameters.AddWithValue("@month", month);
                        cmd.Parameters.AddWithValue("@year", year);
                        cmd.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                        cmd.Parameters.AddWithValue("@AttendanceStatus", comboBox.SelectedIndex + 1);
                        cmd.ExecuteNonQuery();
                    }

                    messageBoxShown = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                messageBoxShown = false;
            }
        }

        private void StudentAttendence_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            LOGIN form = new LOGIN();
            form.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            String connection = @"Data Source=IfraFazal;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select * from StudentAttendance";
            PDF(connection, query);
            MessageBox.Show("Pdf Successfully Created!!!");
        }
        public static void PDF(string connectionString, string query)
        {
            // Connect to the database and retrieve data
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Create a new PDF document and add a page
                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(@"C:\Users\ifraf\Desktop\4th Sem\DATABASE_LABS\DB1\StudentAttendence.pdf", FileMode.Create));

                    // PdfWriter.GetInstance(document, new FileStream("StudentResult.pdf", FileMode.Create));
                    document.Open();

                    // Add a table to the PDF document
                    PdfPTable table = new PdfPTable(reader.FieldCount);
                    table.WidthPercentage = 100;
                    table.SetWidths(new float[] { 2f, 2f, 2f, 2f });

                    // Add headers to the table
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(reader.GetName(i)));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                        table.AddCell(cell);
                    }

                    // Add rows to the table
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            table.AddCell(reader[i].ToString());
                        }
                    }

                    // Add the table to the document
                    document.Add(table);

                    // Close the document and the reader
                    document.Close();
                    reader.Close();
                }
            }
        }


    }
}
