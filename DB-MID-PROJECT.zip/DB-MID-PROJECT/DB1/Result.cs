﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB1
{
    public partial class Result : Form
    {
        public Result()
        {
            InitializeComponent();
            loadData();    
        }
        private void Result_Load(object sender, EventArgs e)
        {
            LoadAssessmentTitles();
            LoadStudentRegistrationNumbers();
            LoadRubricMeasurementLevels();
            LoadRubricMeasurementIds();
            LoadAssessmentComponentIds();
        }

        void LoadAssessmentTitles()
        {
            using (SqlConnection connection = Configuration.getInstance().getConnection())
            {
                connection.Open(); // Open the connection before executing the command

                SqlCommand command = new SqlCommand("SELECT Title FROM Assessment", connection);
                command.CommandTimeout = 60;
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    comboBox3.Items.Add(reader["Title"].ToString());
                }

                reader.Close();
                comboBox3.Text = "Select Assessment";
            }
        }

        void LoadRubricMeasurementIds()
        {
            try
            {
                using (SqlConnection connection = Configuration.getInstance().getConnection())
                {
                    connection.Open(); // Open the connection before executing the command

                    SqlCommand command = new SqlCommand("SELECT Id FROM RubricLevel", connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox2.Items.Add(reader["Id"].ToString());
                    }

                    reader.Close();
                    comboBox2.Text = "Select Rubric Measurement ID";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        void LoadStudentRegistrationNumbers()
        {
            using (SqlConnection connection = Configuration.getInstance().getConnection())
            {
                connection.Open(); // Open the connection before executing the command

                SqlCommand command = new SqlCommand("SELECT RegistrationNumber FROM Student", connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    comboBox1.Items.Add(reader["RegistrationNumber"].ToString());
                }

                reader.Close();
                comboBox1.Text = "Select Registration Number";
            }
        }

        void LoadRubricMeasurementLevels()
        {
            using (SqlConnection connection = Configuration.getInstance().getConnection())
            {
                connection.Open(); // Open the connection before executing the command

                SqlCommand command = new SqlCommand("SELECT MeasurementLevel FROM RubricLevel", connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    comboBox4.Items.Add(reader["MeasurementLevel"].ToString());
                }

                reader.Close();
                comboBox4.Text = "Select Level";
            }
        }


        private void LoadAssessmentComponents(object sender, EventArgs e)
        {
            if (comboBox3.SelectedItem != null)
            {
                using (SqlConnection connection = Configuration.getInstance().getConnection())
                {
                    SqlCommand command = new SqlCommand("SELECT Name FROM AssessmentComponent WHERE AssessmentComponent.AssessmentId IN (SELECT id FROM Assessment WHERE Assessment.Title = @Title)", connection);
                    command.Parameters.AddWithValue("@Title", comboBox3.SelectedItem.ToString());
                    SqlDataReader reader = command.ExecuteReader();

                    comboBox2.Items.Clear();

                    while (reader.Read())
                    {
                        comboBox2.Items.Add(reader["Name"].ToString());
                    }

                    reader.Close();
                    comboBox2.Text = "Select Question";
                }
            }
        }
        void LoadAssessmentComponentIds()
        {
            try
            {
                using (SqlConnection connection = Configuration.getInstance().getConnection())
                {
                    connection.Open(); // Open the connection before executing the command

                    SqlCommand command = new SqlCommand("SELECT Id FROM AssessmentComponent", connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox5.Items.Add(reader["Id"].ToString());
                    }

                    reader.Close();
                    comboBox5.Text = "Select Assessment Component ID";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {

            String connection = @"Data Source=IFRA-FAZAL;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select * from StudentResult";
            PDF(connection, query);
            MessageBox.Show("Pdf Successfully Created!!!");
        }
        public static void PDF(string connectionString, string query)
        {
            // Connect to the database and retrieve data
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Create a new PDF document and add a page
                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(@"C:\Users\ifraf\Desktop\4th Sem\DATABASE_LABS\DB1\StudentResult.pdf", FileMode.Create));

                    // PdfWriter.GetInstance(document, new FileStream("StudentResult.pdf", FileMode.Create));
                    document.Open();

                    // Add a table to the PDF document
                    PdfPTable table = new PdfPTable(reader.FieldCount);
                    table.WidthPercentage = 100;
                    table.SetWidths(new float[] { 2f, 2f, 2f, 2f });

                    // Add headers to the table
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(reader.GetName(i)));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                        table.AddCell(cell);
                    }

                    // Add rows to the table
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            table.AddCell(reader[i].ToString());
                        }
                    }

                    // Add the table to the document
                    document.Add(table);

                    // Close the document and the reader
                    document.Close();
                    reader.Close();
                }
            }
        }


        private bool AlrPresent(string registration_NumberID, string assessment_Component_ID, string new_RubricLevel_ID)
        {
            bool isPresent = false;

            using (SqlConnection connection = Configuration.getInstance().getConnection())
            {
                string query = "SELECT COUNT(*) FROM StudentResult WHERE StudentId = @StudentId AND AssessmentComponentId = @AssessmentComponentId AND RubricMeasurementId = @RubricMeasurementId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StudentId", int.Parse(registration_NumberID));
                    command.Parameters.AddWithValue("@AssessmentComponentId", int.Parse(assessment_Component_ID));
                    command.Parameters.AddWithValue("@RubricMeasurementId", int.Parse(new_RubricLevel_ID));

                    connection.Open();
                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                        isPresent = true;
                }
            }

            return isPresent;
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        if (comboBox4.SelectedIndex > -1 && comboBox2.SelectedIndex > -1 && comboBox1.SelectedIndex > -1 && comboBox3.SelectedIndex > -1)
        //        {
        //            string registrationNumberID = "";
        //            string assessmentComponentID = "";
        //            string newRubricLevelID = "";

        //            // Establish connection
        //            using (SqlConnection connection = Configuration.getInstance().getConnection())
        //            {
        //                connection.Open();

        //                // Fetch Student.Id and New_Table.New_ID
        //                string studentQuery = @"SELECT Student.Id, New_Table.New_ID 
        //                            FROM Student 
        //                            JOIN (
        //                                SELECT AssessmentComponent.Id AS New_ID 
        //                                FROM AssessmentComponent 
        //                                WHERE AssessmentComponent.AssessmentId IN (
        //                                    SELECT id FROM Assessment WHERE Assessment.Title = @Title
        //                                ) AND AssessmentComponent.Name = @Name
        //                            ) AS New_Table 
        //                            ON Student.RegistrationNumber = @RegistrationNumber";

        //                SqlCommand studentCmd = new SqlCommand(studentQuery, connection);
        //                studentCmd.Parameters.AddWithValue("@Name", comboBox2.SelectedItem.ToString());
        //                studentCmd.Parameters.AddWithValue("@Title", comboBox3.SelectedItem.ToString());
        //                studentCmd.Parameters.AddWithValue("@RegistrationNumber", comboBox1.SelectedItem.ToString());

        //                using (SqlDataReader studentReader = studentCmd.ExecuteReader())
        //                {
        //                    while (studentReader.Read())
        //                    {
        //                        registrationNumberID = studentReader["Id"].ToString();
        //                        assessmentComponentID = studentReader["New_ID"].ToString();
        //                    }
        //                }

        //                // Fetch New_RubricLevel.Id
        //                SqlCommand rubricCmd = new SqlCommand("SELECT New_RubricLevel.Id AS ID FROM AssessmentComponent AS New_AssessmentComponent " +
        //                                                        "JOIN RubricLevel AS New_RubricLevel " +
        //                                                        "ON New_RubricLevel.RubricId = New_AssessmentComponent.RubricId " +
        //                                                        "AND New_AssessmentComponent.Name = @Name AND New_RubricLevel.MeasurementLevel = @MeasurementLevel;", connection);
        //                rubricCmd.Parameters.AddWithValue("@MeasurementLevel", int.Parse(comboBox4.SelectedItem.ToString()));
        //                rubricCmd.Parameters.AddWithValue("@Name", comboBox2.SelectedItem.ToString());

        //                using (SqlDataReader rubricReader = rubricCmd.ExecuteReader())
        //                {
        //                    while (rubricReader.Read())
        //                    {
        //                        newRubricLevelID = rubricReader["ID"].ToString();
        //                    }
        //                }

        //                // Insert Student Result
        //                if (!string.IsNullOrEmpty(newRubricLevelID))
        //                {
        //                    using (SqlCommand insertCmd = new SqlCommand("INSERT INTO StudentResult VALUES (@StudentId, @AssessmentComponentId, @RubricMeasurementId, @EvaluationDate)", connection))
        //                    {
        //                        insertCmd.Parameters.AddWithValue("@StudentId", int.Parse(registrationNumberID));
        //                        insertCmd.Parameters.AddWithValue("@AssessmentComponentId", int.Parse(assessmentComponentID));
        //                        insertCmd.Parameters.AddWithValue("@RubricMeasurementId", int.Parse(newRubricLevelID));
        //                        insertCmd.Parameters.AddWithValue("@EvaluationDate", dateTimePicker1);

        //                        insertCmd.ExecuteNonQuery();
        //                        MessageBox.Show($"Marks of {registrationNumberID} are marked!");

        //                        // Reset combo box selections
        //                        comboBox1.Text = "Select Student";
        //                        comboBox3.Text = "Select Assessment";
        //                        comboBox4.Text = "Select Level";
        //                        comboBox2.Text = "Rubric leveL Id";

        //                        // Load data into data grid view
        //                        loadData();
        //                    }
        //                }
        //                else
        //                {
        //                    MessageBox.Show("This question does not have a rubric level.");
        //                }
        //            }
        //        }
        //        else
        //        {
        //            MessageBox.Show("Something is missing.");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }

        //}

        // accha walla ===========================================================================================================
        //private void button1_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        if (comboBox4.SelectedIndex > -1 && comboBox2.SelectedIndex > -1 && comboBox1.SelectedIndex > -1 && comboBox3.SelectedIndex > -1)
        //        {
        //            string registrationNumberID = comboBox1.SelectedItem.ToString();
        //            string newRubricLevelID = comboBox2.SelectedItem.ToString(); // Rubric Measurement ID
        //            string assessmentTitle = comboBox3.SelectedItem.ToString();
        //            string assessmentComponentName = comboBox2.SelectedItem.ToString();

        //            // Insert Student Result
        //            using (SqlConnection connection = Configuration.getInstance().getConnection())
        //            {
        //                connection.Open();

        //                // Fetch Student Id
        //                SqlCommand studentCmd = new SqlCommand("SELECT Id FROM Student WHERE RegistrationNumber = @RegistrationNumber", connection);
        //                studentCmd.Parameters.AddWithValue("@RegistrationNumber", registrationNumberID);
        //                int studentId = (int)studentCmd.ExecuteScalar();

        //                // Fetch Assessment Component Id
        //                SqlCommand componentCmd = new SqlCommand("SELECT Id FROM AssessmentComponent WHERE Name = @Name AND AssessmentId IN (SELECT Id FROM Assessment WHERE Title = @Title)", connection);
        //                componentCmd.Parameters.AddWithValue("@Name", assessmentComponentName);
        //                componentCmd.Parameters.AddWithValue("@Title", assessmentTitle);
        //                int assessmentComponentId = (int)componentCmd.ExecuteScalar();

        //                // Insert Student Result
        //                using (SqlCommand insertCmd = new SqlCommand("INSERT INTO StudentResult (StudentId, AssessmentComponentId, RubricMeasurementId, EvaluationDate) VALUES (@StudentId, @AssessmentComponentId, @RubricMeasurementId, @EvaluationDate)", connection))
        //                {
        //                    insertCmd.Parameters.AddWithValue("@StudentId", studentId);
        //                    insertCmd.Parameters.AddWithValue("@AssessmentComponentId", assessmentComponentId);
        //                    insertCmd.Parameters.AddWithValue("@RubricMeasurementId", newRubricLevelID);
        //                    insertCmd.Parameters.AddWithValue("@EvaluationDate", DateTime.Now); // You may need to adjust this

        //                    insertCmd.ExecuteNonQuery();
        //                    MessageBox.Show($"Marks of {registrationNumberID} are marked!");

        //                    // Reset combo box selections
        //                    comboBox1.Text = "Select Student";
        //                    comboBox3.Text = "Select Assessment";
        //                    comboBox4.Text = "Select Level";
        //                    comboBox2.Text = "Select Rubric Measurement ID";

        //                    // Load data into data grid view
        //                    loadData();
        //                }
        //            }
        //        }
        //        else
        //        {
        //            MessageBox.Show("Something is missing.");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }

        //}
        //============================================================================================

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedIndex > -1 && comboBox2.SelectedIndex > -1 && comboBox3.SelectedIndex > -1 && comboBox4.SelectedIndex > -1)
                {
                    string registrationNumberID = comboBox1.SelectedItem.ToString();
                    string rubricMeasurementID = comboBox2.SelectedItem.ToString();
                    string assessmentTitle = comboBox3.SelectedItem.ToString();
                    string level = comboBox4.SelectedItem.ToString();

                    // Fetch Student Id
                    int studentId;
                    using (SqlConnection connection = Configuration.getInstance().getConnection())
                    {
                        connection.Open();
                        SqlCommand studentCmd = new SqlCommand("SELECT Id FROM Student WHERE RegistrationNumber = @RegistrationNumber", connection);
                        studentCmd.Parameters.AddWithValue("@RegistrationNumber", registrationNumberID);
                        studentId = (int)studentCmd.ExecuteScalar();
                    }

                    //// Fetch Assessment Component Id
                    //int assessmentComponentId;
                    //using (SqlConnection connection = Configuration.getInstance().getConnection())
                    //{
                    //    connection.Open();
                    //    SqlCommand componentCmd = new SqlCommand("SELECT Id FROM AssessmentComponent WHERE Name = @Name AND AssessmentId IN (SELECT Id FROM Assessment WHERE Title = @Title)", connection);
                    //    componentCmd.Parameters.AddWithValue("@Name", assessmentTitle);
                    //    componentCmd.Parameters.AddWithValue("@Title", assessmentTitle);
                    //    assessmentComponentId = (int)componentCmd.ExecuteScalar();
                    //}

                    // Insert Student Result
                    int newRubricLevelID;
                    using (SqlConnection connection = Configuration.getInstance().getConnection())
                    {
                        connection.Open();
                        SqlCommand rubricCmd = new SqlCommand("SELECT Id FROM RubricLevel WHERE RubricLevelId = @RubricLevelId", connection);
                        rubricCmd.Parameters.AddWithValue("@RubricLevelId", rubricMeasurementID);
                        newRubricLevelID = (int)rubricCmd.ExecuteScalar();
                    }

                    // Insert Student Result
                    using (SqlConnection connection = Configuration.getInstance().getConnection())
                    {
                        connection.Open();
                        using (SqlCommand insertCmd = new SqlCommand("INSERT INTO StudentResult (StudentId, AssessmentComponentId, RubricMeasurementId, EvaluationDate) VALUES (@StudentId, @AssessmentComponentId, @RubricMeasurementId, @EvaluationDate)", connection))
                        {
                            insertCmd.Parameters.AddWithValue("@StudentId", studentId);
                          //  insertCmd.Parameters.AddWithValue("@AssessmentComponentId", assessmentComponentId);
                            insertCmd.Parameters.AddWithValue("@RubricMeasurementId", newRubricLevelID);
                            insertCmd.Parameters.AddWithValue("@EvaluationDate", DateTime.Now); // You may need to adjust this

                            insertCmd.ExecuteNonQuery();
                            MessageBox.Show($"Marks of {registrationNumberID} are marked!");

                            // Reset combo box selections
                            comboBox1.Text = "Select Student";
                            comboBox3.Text = "Select Assessment";
                            comboBox4.Text = "Select Level";
                            comboBox2.Text = "Select Rubric Measurement ID";

                            // Load data into data grid view
                            loadData();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Something is missing.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void loadData()
        {
            using (SqlConnection connection = Configuration.getInstance().getConnection())
            {
                string query = "SELECT * FROM StudentResult";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Set command timeout to a larger value (in seconds), e.g., 60 seconds
                    command.CommandTimeout = 60;

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("No Student ID provided to be deleted.");
                }
                else
                {
                    using (var connection = Configuration.getInstance().getConnection())
                    {
                        SqlCommand cmd = new SqlCommand("DELETE FROM StudentResult WHERE StudentId = @StudentId", connection);
                        cmd.Parameters.AddWithValue("@StudentId", textBox1.Text);

                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record deleted successfully.");
                            this.Refresh();
                            data();
                        }
                        else
                        {
                            MessageBox.Show("No records found for the provided Student ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
        public void data()
        {
            var Con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from StudentResult", Con);
            cmd.CommandTimeout = 120; // Increase the command timeout to 120 seconds (adjust as needed)
            SqlDataAdapter dt = new SqlDataAdapter(cmd);
            DataTable dta = new DataTable();
            dt.Fill(dta);
            dataGridView1.DataSource = dta;
        }

        private void button8_Click(object sender, EventArgs e)
        {

            try
            {
                // Check if any rows are selected
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Get the selected row
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    // Remove the selected row from the DataGridView
                    dataGridView1.Rows.Remove(selectedRow);

                    MessageBox.Show("Record removed from the grid successfully", "Success");
                }
                else
                {
                    MessageBox.Show("Please select a row to remove", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }
    }
}
